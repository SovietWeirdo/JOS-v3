import os
import time
data_info = open('user/info.data')
data = data_info.read()

if data == '0':
	print("Opening register page...")
	time.sleep(1)
	os.startfile("setup.py")
if data == '1':
	print("opening login...")
	time.sleep(1)
	os.startfile("login.py")