from cmath import sqrt
import os

num_1 = int(input('Enter your first number: '))
num_2 = int(input('Enter your second number: '))
 
# Addition
print('{} + {} = '.format(num_1, num_2))
print(num_1 + num_2)
 
# Subtraction
print('{} - {} = '.format(num_1, num_2))
print(num_1 - num_2)
 
# Multiplication
print('{} * {} = '.format(num_1, num_2))
print(num_1 * num_2)
 
# Division
print('{} / {} = '.format(num_1, num_2))
print(num_1 / num_2)

# Square root
print("Square root of first number =")
print(sqrt(num_1))

continu = input("Would you like to do another eqaution? (y/n) ")
if continu == 'y':
    os.startfile('calcuator.py')
else:
    exit()