import os
import time
with open('user/info.data', 'w') as f:
    f.writelines('1')

print("""

░░░░░██╗░█████╗░░██████╗  ██╗░░░██╗░░░██████╗░
░░░░░██║██╔══██╗██╔════╝  ██║░░░██║░░░╚════██╗
░░░░░██║██║░░██║╚█████╗░  ╚██╗░██╔╝░░░░█████╔╝
██╗░░██║██║░░██║░╚═══██╗  ░╚████╔╝░░░░░╚═══██╗
╚█████╔╝╚█████╔╝██████╔╝  ░░╚██╔╝░░██╗██████╔╝
░╚════╝░░╚════╝░╚═════╝░  ░░░╚═╝░░░╚═╝╚═════╝░

░██████╗███████╗████████╗██╗░░░██╗██████╗░
██╔════╝██╔════╝╚══██╔══╝██║░░░██║██╔══██╗
╚█████╗░█████╗░░░░░██║░░░██║░░░██║██████╔╝
░╚═══██╗██╔══╝░░░░░██║░░░██║░░░██║██╔═══╝░
██████╔╝███████╗░░░██║░░░╚██████╔╝██║░░░░░
╚═════╝░╚══════╝░░░╚═╝░░░░╚═════╝░╚═╝░░░░░
""")

name = input("username for JOS V3 account: ")
pas = input("password for JOS V3 account: ")
with open('user/username.data', 'w') as f:
    f.writelines(name)
with open('user/password.data', 'w') as f:
    f.writelines(pas)

print("setup complete")
print("Opening homepage...")
time.sleep(1)
os.startfile('home.py')