from ipaddress import *
import os
import time
import socket
hostname = socket.gethostname()
IPAdres = socket.gethostbyname(hostname)

login_name = open('user/username.data')
login_pass = open('user/password.data')
ln = login_name.read()
lp = login_pass.read()

print("""
░░░░░██╗░█████╗░░██████╗  ██╗░░░██╗░░░██████╗░
░░░░░██║██╔══██╗██╔════╝  ██║░░░██║░░░╚════██╗
░░░░░██║██║░░██║╚█████╗░  ╚██╗░██╔╝░░░░█████╔╝
██╗░░██║██║░░██║░╚═══██╗  ░╚████╔╝░░░░░╚═══██╗
╚█████╔╝╚█████╔╝██████╔╝  ░░╚██╔╝░░██╗██████╔╝
░╚════╝░░╚════╝░╚═════╝░  ░░░╚═╝░░░╚═╝╚═════╝░
""")

print("Hi, " + ln)
print("the date is " + time.strftime("%m/%d/%y"))
print("""
[1] to open text editor
[2] to open tkinter file explorer
[3] to configure and open BioS
[4] to open terminal
[5] to open calcuator
[6] to open google (google must be pre-installed)
[7] to close OS
""")

select = input("[?]: ")
if select == '1':
    os.startfile('home.py')
    os.startfile("notepad")
if select == '2':
    os.startfile('home.py')
    os.startfile('tkinterfileexplorer.py')
if select == '3':
    biosPass = input("password to " + ln + " ")
    if biosPass == lp:
        print("[1]Username = " + ln)
        print("[2]password = " + lp)
        print("[3]account active = yes")
        print("host name = " + hostname)
        print("Ip address = " + IPAdres)
        configure = input("[?]: ")
        if configure == '1':
            newUser = input("What is your new username? ")
            with open('user/username.data', 'w') as f:
                f.writelines(newUser)
        if configure == '2':
            newPass = input("What is your new password? ")
            with open('user/password.data', 'w') as f:
                f.writelines(newPass)
        if configure == '3':
            print("By continuing you accept that your current account will be deleted from this OS")
            delete = input("y/n ")
            if delete == 'y':
                input("by pressing enter the account will be gone forever")
                with open('user/info.data', 'w') as f:
                    f.writelines("0")
                    exit()
    else:
        print("wrong password, data could be being compromised, closing JOS V3")
        input()
        exit()
    os.startfile('home.py')
if select == '4':
    os.startfile('home.py')
    os.startfile('CMD.EXE')
if select == '5':
    os.startfile('home.py')
    os.startfile('calcuator.py')
if select == '6':
    os.startfile('home.py')
    os.startfile('chrome.EXE')